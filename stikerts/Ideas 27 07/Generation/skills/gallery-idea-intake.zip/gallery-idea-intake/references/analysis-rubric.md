# Analysis rubric — how existing entries were classified

Distilled from `Idea-Board-Solutions-Reference.md` and the patterns
actually used across the 66 existing entries. Apply this consistently —
the gallery's own history is a cautionary tale about NOT doing so (see
"The core principle" below).

## The core principle (read this before classifying anything)

**"Needs fine detail or multiple colours" is not the same problem as
"needs Cricut."** This business's actual production method is print
(inkjet) → laminate → guillotine-trim a rectangle. An inkjet printer
doesn't care whether it's printing a straight line or a raccoon's
individual whiskers — both cost the same ink and a few seconds.

`cutting` = `needs_cricut` applies ONLY when:
1. The final product genuinely needs to be a **shape other than a
   rectangle, with no card/background** (a true die-cut oval, house
   outline, hexagon, wreath ring) — cutting the shape itself is
   unavoidable, OR
2. The **material itself** must be physically cut, not printed
   (reflective/holographic vinyl — these are pre-made reflective sheets,
   not something you print on).

Everything else — however detailed, however many colours, however
"delicate" it would look as cut vinyl — is `doable_now`: printed as ink
on the standard rectangle card, guillotine-trimmed, exactly like the
existing designs.

**Early in this gallery's history, ~35 of 52 entries were wrongly marked
`needs_cricut`** using cut-vinyl intuition (fine detail = hard to weed)
that doesn't apply to a print-based workflow. Don't repeat that mistake.
If your first instinct is "needs Cricut" because something looks
detailed or colourful, stop and ask: is the actual BLOCKER the shape, or
the material — or is it actually fine, and you're pattern-matching on
"looks intricate" instead?

One more blocker worth checking explicitly: **white ink**. This printer
has no white ink channel (no consumer inkjet does). A design that's
white-on-bin-colour direct with no card can't be printed as-is — either
redesign in a printable dark colour, or file as a genuine future item
(true white-on-clear needs a different printer entirely).

## Classifying `set`

- **"House Number & Street Name"** / **"Numbers"** / **"Street Name"** —
  the design shows genuine personalised content matching one of these
  patterns, and there's a plausible path to producing it (even if
  adapted).
- **"Inspiration Only"** — use this when ANY of the following apply,
  regardless of how well-executed the design itself is:
  - **No personalisation at all** (a decorative "bin face," a generic
    character with no number/name field) — this is disqualifying on its
    own even if production is trivially easy. The core of this business
    is personalisation; decorative-only doesn't fit the model.
  - **Licensed/copyrighted characters** (Star Wars, Smurfs, LEGO
    Ninjago, etc.) — check the Business Plan's explicit rule against
    this. State plainly "Can we create it? No — copyright" and name the
    IP; don't hedge.
  - **Out of scope entirely** — not an adhesive sticker (wall-mounted
    hardware, a solar sign, a full bin wrap needing a different printer
    class entirely).
  - **Wrong technique/product category** — hand-painted rather than
    printed/cut, or a completely different size class (a full-panel
    wrap vs. a small corner sticker).

  For Inspiration Only entries: `selling` = `"N/A"`, `fits_per_a4` and
  `cost_unit` = `"N/A — inspiration only"`. Still write a real, useful
  Notes field — usually leading with **"Can we create it?"** followed by
  a direct yes/no and the specific reason.

## Classifying `selling`

Don't rate in a vacuum. Two things matter more than a standalone gut
read:

1. **Repeat sightings.** If the same concept has shown up before across
   the gallery, say so explicitly by ID ("5th sighting of the
   house-outline+number concept, after P10, P19, P20, P27") — a repeated
   pattern across independent sources is stronger evidence than any
   single pin, and should push the rating up. This is one of the most
   consistently useful things existing Notes fields do; don't skip it.
2. **Real commercial evidence**, when present in the source — review
   counts, "bestseller" badges, stated sales volume ("1K+ bought in past
   month"), a real price point on an actively-sold listing vs. a
   Pinterest mockup with no evidence behind it at all.

`Very High` is reserved for entries with strong real evidence (high
review count + bestseller status), not just "this looks nice."

## Writing `technique` and `notes`

`technique`: one concrete line — colour count, cut-vs-print, single vs.
composite icon. Not a restatement of the image description.

`notes`: this is where judgment lives. Typical structure seen across
existing entries:
- If Inspiration Only or blocked: lead with **"Can we create it?"** and
  answer directly.
- If reclassified from an earlier wrong "needs Cricut" instinct: say so
  explicitly ("the only reason this was marked needs_cricut was X — a
  cut-vinyl limitation, not a printing one — reclassified to doable
  now"), don't just silently output the corrected verdict.
- Cross-reference related entries by ID whenever the pattern applies —
  this is what makes the "repeat sighting" signal for `selling`
  meaningful and checkable later, not just an assertion.

## Grouped duplicates (e.g. `P09a`, `P09b`)

If a new image is the *same design*, shown on a different bin colour or
in a different photo, as an existing entry — don't create a new
sequential ID. Use a lettered variant of the existing ID instead (check
`inspect_gallery()`'s id list for what's already used) and note in
`notes` that it's the same design as the original, cross-referencing it,
same as the existing P09a/P09b pair.
