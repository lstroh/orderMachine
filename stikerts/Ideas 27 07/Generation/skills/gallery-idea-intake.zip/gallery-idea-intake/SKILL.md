---
name: gallery-idea-intake
description: Analyses a raw design image (screenshot, product photo, Pinterest pin, marketplace listing — from anywhere) the same way the existing 66 entries in bin_sticker_idea_gallery.html were analysed, and adds it as a new fully-formed entry in that HTML file. Trigger this whenever the user shares an image and says something like "add this to the gallery", "is this doable", "new idea for the board", "what would it take to make this", or uploads a competitor/inspiration image without further instruction. Also trigger for "how many ideas do we have", "check the gallery", or any request to inspect/verify the gallery file's current state. Do NOT trigger this for adding a new working STYLE to bin_sticker.py itself (writing a `_style_*` function) — that's a different, code-focused task; this skill only touches the research/idea-board HTML file.
---

# Gallery Idea Intake

Adds a new entry to `bin_sticker_idea_gallery.html` — the research/idea
board of competitor and inspiration designs (currently 66 entries, P01–P62
with some grouped duplicates) — from a raw source image, following the
exact same analytical rubric and HTML structure already used throughout
that file.

**This is a research/cataloguing task, not a code task.** It never touches
`bin_sticker.py`. If the user actually wants a new *working design* in the
sticker generator itself, that's a separate, larger effort (art generation
→ icon-silhouette-extraction → writing a `_style_*` function) — check
which one they mean if it's ambiguous.

## Before doing anything: read the file's actual current state

```python
import gallery_io as gio
gio.inspect_gallery(path)
```

This tells you the current card count, the next available ID, the full
list of existing themes, and runs a colour-table spot-check. **If that
spot-check reports a mismatch, stop and re-derive the colour tables in
`gallery_io.py` before proceeding** — it means the file has been edited by
hand since this skill was last used, and the module's assumptions about
structure/colours may be stale. Silently writing a new card against wrong
assumptions produces a card that looks fine in isolation but breaks the
filter dropdowns or renders with no tag colour.

## Step 1: understand the source image

Look at what's actually in the image — what's shown, what bin colour(s)
if any, what text/numbers appear, what production technique it implies
(cut vinyl direct-on-bin? printed card? multi-colour illustration?). If
the user gave you a source (a listing URL, a shop name, a price, review
count), keep that — it's exactly the kind of detail existing entries
record (see e.g. P47's "'Stickers Limited' — 4.7★ (4,272 reviews)").

## Step 2: apply the established analytical rubric

**Read `references/analysis-rubric.md` before filling in any field** — it
encodes the specific, previously-corrected reasoning this gallery uses
for "Fits spec", "Production/Cutting", and "Solutions", which is easy to
get wrong by applying generic cut-vinyl intuition instead. Getting this
wrong isn't a cosmetic error — the whole point of the gallery's most
important correction (documented in `Idea-Board-Solutions-Reference.md`
§6) was that ~35 of the original 52 entries were mis-classified "needs
Cricut" before this rubric was applied consistently. Don't repeat that
mistake on new entries.

Determine, in order:
1. **Set** — one of the 4 existing sets ("House Number & Street Name",
   "Numbers", "Street Name", "Inspiration Only"). Inspiration Only is for
   anything with no clear personalisation path or that's out of scope
   entirely (not a sticker, wrong material category) — check
   `references/analysis-rubric.md` for the exact criteria.
2. **Theme** — reuse an existing theme from `inspect_gallery()`'s list if
   it genuinely fits; only introduce a new one if it doesn't (adds a
   dropdown option, small but real cost to the filter's usefulness if
   overused for near-duplicate themes).
3. **Fits 100×140mm spec** (`fits`: True/False) — does the pinned size
   (if stated) or the visual proportions match the card, or is this
   pinned at a different size/shape that would need adaptation?
4. **Production** (`cutting`: doable_now/needs_cricut) — per the rubric,
   this is almost always `doable_now` unless the final product genuinely
   needs a die-cut shape with no card background, or a material that must
   be physically cut (reflective/holographic vinyl). Fine detail, many
   colours, delicate line work — none of these alone justify
   `needs_cricut` once printed as ink on a card.
5. **Solutions** (list of `WC`/`CV`/`PTC`/`CRICUT`/`NA`) — which
   production paths actually apply; usually `["WC", "CV"]` for anything
   doable now.
6. **Selling potential** — compare against similar existing entries (same
   theme/structure) rather than rating in a vacuum; note in the selling
   field WHY (e.g. "5th sighting of this exact concept" is a stronger
   signal than a standalone guess — see how P47/P48 do this).
7. **Technique** — one line, concrete: what's literally being done
   (colour count, cut-vs-print, single vs multi-element).
8. **Notes** — this is where the "doable now" reasoning, corrections to
   an initial instinct, and cross-references to related entries (by ID)
   belong. Look at a few existing notes fields for tone/length before
   writing this — they're substantive, not a one-liner.

## Step 3: build and insert the entry

```python
entry = {
    "id": gio.next_id(path),
    "set": "...", "theme": "...", "title": "...",
    "image_desc": "...",  # objective description of what's IN the image, not your analysis
    "image_data_uri": gio.image_to_data_uri(source_image_path),
    "fits": "True" or "False",
    "cutting": "doable_now" or "needs_cricut",
    "solutions": ["WC", "CV"],  # subset of WC/CV/PTC/CRICUT/NA
    "selling": "High",  # one of: Very High / High / Medium-High / Medium / N/A
    "size_pinned": "...", "technique": "...", "fits_per_a4": "...",
    "cost_unit": "...", "selling_note": "...", "notes": "...",
}
new_id = gio.insert_card(path, entry, out_path=out_path)
gio.verify_gallery(out_path, expected_card_count=<old_count + 1>)
```

Always write to a new `out_path` first, run `verify_gallery`, and only
then present it as the replacement for the real file — don't overwrite
the user's only copy before confirming the write succeeded cleanly.

## Step 4: keep the text companion in sync (ask once, then remember)

`bin_sticker_idea_board_data.md` is a text-only export of the same data,
explicitly described as staying in sync with the HTML gallery ("IDs match
the gallery exactly"). Ask the user once per session whether they want
new entries appended there too in the matching format (see any existing
entry in that file for the exact heading/field layout) — default to yes
if they don't have a strong preference, since leaving it out of sync
contradicts what that file's own header claims about itself.

## Step 5: tell the user what you did and why

Summarize the classification decisions (especially anything non-obvious —
why doable_now vs needs_cricut, why this Set/Theme) rather than just
presenting the finished card. If a field was genuinely ambiguous (source
size not stated, unclear if it's a real product photo or a marketing
mockup), say so rather than picking silently — same standard as any other
research/analysis task.
