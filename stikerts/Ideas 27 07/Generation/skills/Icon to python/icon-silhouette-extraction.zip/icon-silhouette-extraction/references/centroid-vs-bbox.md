# Centroid vs. bounding-box midpoint

For a rectangular hollow, the bounding box's midpoint and the shape's
visual "middle" are the same point. For almost anything else, they aren't.

**Concrete example**: a house-shaped hollow — a triangular roof interior
sitting on top of a wider rectangular body — has more of its area low
down (the wide rectangular part) than up high (the narrow triangular
part). Its pixel-mass centroid sits measurably *below* its bounding box's
vertical midpoint, because that's where more of the actual area is.

If you centre text on the bounding-box midpoint of a shape like this, it
will look too high — visibly not "centred in the middle of the house"
even though it's mathematically centred in the bounding rectangle around
the house's hollow.

**Rule**: use the pixel centroid (mean x, mean y of all pixels in the
region — `component_centroid()` in this skill's utils) instead of the
bounding-box midpoint for any hollow/shape that isn't a simple rectangle.
The difference was measured at ~10px (about 2mm at the scale used) in one
real case here — small enough to miss if you don't check, large enough
to visibly look wrong once rendered.

If you have a source image with real baked-in content (e.g. text that was
actually placed by a person) rather than an empty hollow to analyse, prefer
using *that* content's actual centroid as ground truth over inferring
anything from the hollow's shape — a human already made the "where does
this visually belong" judgment call for you; measuring their answer
directly is more reliable than re-deriving it from geometry.
