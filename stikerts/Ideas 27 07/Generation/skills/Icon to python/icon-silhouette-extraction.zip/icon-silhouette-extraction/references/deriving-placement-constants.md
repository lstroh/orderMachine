# Deriving placement constants — worked example

This walks through turning the measurements from `silhouette_utils.py`
into the actual constants a renderer needs, using the real case this
skill was extracted from (a reportlab-based sticker generator,
`bin_sticker.py`, style "P02": a house+banner icon with a nested house
number and a curved street-name text).

Your renderer's conventions will differ in the details, but the shape of
the conversion (pixel measurements → physical placement constants) is the
same.

## 1. Know your two coordinate systems

Image analysis happens in **pixel space**: origin top-left, x right,
y *down*, units = pixels.

Most page-layout renderers (reportlab included) use **render space**:
origin bottom-left of the card, x right, y *up*, units = mm or points.

You need one consistent scale factor (mm per pixel) and one offset to
convert between them. Get the scale factor by deciding how big the icon
should be on the card (a design choice, not something derived from the
image) — e.g. "the icon should be 82.8mm wide out of a 100mm card" — then:

```python
scale = icon_width_mm / source_image_width_px
```

Everything else follows from that one number plus where you decide to
place the icon's top-left corner on the card.

## 2. Converting a measured centroid to a render-space constant

Say `component_centroid()` gave you `(cx_px, cy_px)` in the *cropped
asset's local pixel space* (remember to subtract the crop offset first if
you measured in the original image).

```python
# icon_x_left, icon_y_top: where you've decided to place the icon's
# top-left corner, in render-space mm, measured from the CARD's top-left
# (top-down, matching pixel-space's y-direction, for this half of the
# conversion)
x_topdown_mm = icon_x_left_mm + cx_px * scale
y_topdown_mm = icon_y_top_mm + cy_px * scale

# now flip into the renderer's bottom-up render space:
y_render_mm = card_height_mm - y_topdown_mm
x_render_mm = x_topdown_mm  # x direction is the same in both systems
```

In the real case, this produced (after choosing icon placement centred
horizontally and vertically within the card's usable interior):

```python
P02_NUMBER_CENTER_Y = 76.615 * mm   # "36"'s vertical centre, render space
P02_STREET_CENTER_Y = 60.045 * mm   # "GROVE STREET"'s vertical centre
```

The horizontal centre in that case came out within ~1mm of the icon's own
geometric centre both times (i.e. dead centre of the card) — a useful
sanity check that the measurement is trustworthy: if a centroid comes out
wildly off-centre from where the icon itself is centred, and there's no
good reason (the source content isn't meant to be off-centre), double
check the classification step (§3 in SKILL.md) before trusting the number.

## 3. Converting a measured width to an auto-fit max-width constant

`measure_gap()` or `trace_band()`'s usable x-range give you a raw pixel
width. Convert to mm the same way (`width_px * scale`), then apply a
safety margin before using it as a hard constraint for auto-fitting text —
text metrics (font rendering, kerning) won't match your measurement
exactly, and you want the *effective* limit tighter than the true physical
limit:

```python
P02_NUMBER_MAX_WIDTH = house_gap_px * scale * 0.90 * mm   # 10% margin
P02_STREET_MAX_WIDTH = banner_width_px * scale * 0.90 * mm
```

Then auto-fit at render time (shrink font size until it fits) rather than
hard-coding one font size — different orders will have different text
lengths, and a fixed size that worked for your one test string ("36",
"Grove Street") won't work for a longer one ("1400", "Old Winchester
Road"). Test with a deliberately long case before considering this done.

## 4. Converting a fitted curve into a render-time curve function

`fit_curve()` gives you polynomial coefficients in the *cropped asset's
local pixel space*. To use them at render time (deciding each character's
vertical offset and rotation as it's drawn along the curve), you need the
same scale/offset conversion as above, applied per-character:

```python
def curve_mid_px(x_px, coeffs):
    a, b, c = coeffs
    return a*x_px*x_px + b*x_px + c

def draw_curved_text(c, text, cx_mm, baseline_mm, icon_x_left_mm, scale, coeffs):
    # find the reference point's curve value (character at the text's own centre)
    x_img_at_cx = (cx_mm - icon_x_left_mm) / scale
    ref_mid_px = curve_mid_px(x_img_at_cx, coeffs)
    a, b, _ = coeffs

    x_cursor = cx_mm - text_width_mm / 2
    for ch in text:
        char_w = char_width_mm(ch)
        x_char = x_cursor + char_w / 2
        x_img = (x_char - icon_x_left_mm) / scale
        mid_px = curve_mid_px(x_img, coeffs)
        # pixel space y increases DOWN, render space y increases UP:
        delta_y_mm = -(mid_px - ref_mid_px) * scale
        slope = 2*a*x_img + b               # dy/dx in pixel space (unitless, scale cancels)
        angle_deg = -degrees(atan(slope))   # sign-flipped for the same reason as delta_y
        # draw this character at (x_char, baseline_mm + delta_y_mm), rotated by angle_deg
        x_cursor += char_w
```

**A real bug this caught**: if your renderer places the same icon at
multiple positions on a page (e.g. 4-up on a sheet), `icon_x_left_mm` is
different for each position — it must include that card's offset within
the page, not just the icon's offset within its own card. Passing a
card-local-only constant (forgetting to add the page position) works by
coincidence for whichever card happens to sit at the page's own origin,
and produces wildly wrong rotations (points far outside the curve fit's
valid domain, where the slope term has been linearly extrapolated way
past where it means anything) for every other position. If curved text
looks fine in isolation but breaks specifically when placed at a second
position on a multi-up layout, check this first.

## 5. Verify against the render, not just the numbers

Static ranges are hard to verify with an untrained eye. Once you have real
output, verify empirically by re-measuring the *rendered* result — draw
a card, rasterize it, and check pixel positions of the text you placed
directly, rather than only trusting the geometry math to have been applied
correctly:

```python
# find the rendered street text's pixel positions across a few x-columns,
# confirm the middle sits higher (smaller y) than the two ends for a
# banner that's supposed to dip at the edges, etc.
```

This is slower than trusting the math, but it's what actually caught the
sheet-position bug described above — the math looked correct in isolation
and only the rendered output revealed the missing offset.
