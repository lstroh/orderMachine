# Recolour-by-alpha-mask pipelines

A common pattern for a "recolourable icon" system: a function that takes a
single-colour silhouette PNG and a target hex colour, and repaints every
non-transparent pixel to that colour — using each pixel's *own alpha value*
as its opacity, so the original RGB is discarded entirely.

```python
def recolour_silhouette(in_path, out_path, hex_color):
    img = Image.open(in_path).convert("RGBA")
    r, g, b = tuple(int(hex_color.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
    pixels = img.load()
    for y in range(img.height):
        for x in range(img.width):
            _, _, _, a = pixels[x, y]
            if a > 0:
                pixels[x, y] = (r, g, b, a)
    img.save(out_path)
```

**The consequence for extraction**: if your source image has a visual
hierarchy encoded in *colour* (e.g. a bold black house outline next to a
lighter grey banner outline), and you build your silhouette by copying RGB
through unchanged, that hierarchy survives right up until someone runs this
recolour function on it — at which point every non-transparent pixel
becomes the exact same flat colour, and the hierarchy is gone.

**The fix**: re-encode any tonal/visual-weight difference as an *alpha*
difference before saving the silhouette, since alpha is the only channel
that survives recolouring. A component that was originally lighter/thinner
should get a lower alpha (so it recolours to a lighter *tint* of the target
colour, blending toward whatever it's composited over), not a lower-opacity
version of its original colour.

```python
# after labelling, before saving:
new_alpha[banner_component_mask] = original_alpha[banner_component_mask] * 0.76
```

Check whether your specific downstream consumer actually works this way
before doing this — if it recolours by literally replacing RGB and keeping
original alpha only for edge anti-aliasing (not for a deliberate hierarchy),
this step is unnecessary and you should just keep faithful RGB instead.
