# Full-layout mockup prompt templates

These are the actual prompts used for P02 (verified from chat history),
kept here verbatim as the pattern to generalise from — not reconstructed
from memory.

## Midjourney template

```
A [design summary] design for a wheelie bin, featuring [icon elements
and their arrangement], with the [primary personalised field, e.g. house
number] '[example value]' displayed [where it sits relative to the
icon], and [secondary element if any, e.g. a ribbon banner] containing
[secondary field, e.g. street name] '[example value]' in [text style],
clean flat vector illustration, single accent colour with black text, on
a plain white card with a thin border, portrait orientation --style raw
--stylize 50 --ar 5:7
```

**Real example (P02):**

```
A house address sticker design for a wheelie bin, featuring a
minimalist house icon flanked by two small flowers, with the house
number '36' displayed prominently near the roofline, and a ribbon
banner below containing the street name 'GROVE STREET' in bold caps
text, clean flat vector illustration, single accent colour with black
text, on a plain white card with a thin border, portrait orientation
--style raw --stylize 50 --ar 5:7
```

Note `--ar 5:7` — matches the 100×140mm card's real proportions. If the
design being explored isn't meant for that card size (check its `fits`
field in the gallery), adjust the ratio to match instead of leaving this
in by default.

## Lovart template (conversational style)

```
Design a wheelie bin address sticker layout, portrait orientation,
roughly 100mm wide by 140mm tall. Include [icon elements and
arrangement], with the [primary field] '[example value]' placed [where],
and [secondary element] containing [secondary field] '[example value]'
in [text style]. Plain white card background with a thin border. This
is for composition and layout reference only — the text is a
placeholder and will not be used exactly as generated.
```

**Real example (P02):**

```
Design a wheelie bin address sticker layout, portrait orientation,
roughly 100mm wide by 140mm tall. Include a minimalist house icon
flanked by two small flowers near the top, with the number '36' placed
near the roofline, and a ribbon banner below containing the street name
'GROVE STREET' in bold capital letters. Plain white card background with
a thin border. This is for composition and layout reference only — the
text is a placeholder and will not be used exactly as generated.
```

## What to do with the result (include this note alongside both prompts)

Don't extract or trace the placeholder text directly. Instead, look at
where things sit — icon size relative to the card, gaps between
elements, secondary-element width vs. card width — and describe that
back (or share the image) so it can be translated into exact reportlab
coordinates with the real font and guaranteed-correct text, the same way
P02's actual placement constants were derived.

## Adapting for designs without a number+street structure

Not every gallery entry is "icon + number + street name." For a
Numbers-only design, drop the secondary/banner element and its field
entirely. For a Street-Name-only design, drop the primary numbered field.
Keep the same bones (icon description, portrait card proportions,
placeholder-text warning) — the specific fields are what change per
design, not the overall shape of the prompt.
