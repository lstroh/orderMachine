"""
gallery_io.py — read/write helpers for bin_sticker_idea_gallery.html,
shared by the gallery-idea-intake and gallery-mockup-prompt skills.

This module knows the ONE gallery file's exact structure (verified against
the real file, not assumed):
  - each idea is a <div class="card" data-set=... data-cutting=...
    data-fits=... data-selling=... data-solutions="CODE CODE ...">
  - inline base64 <img>, no external image files
  - fixed hex colour per tag VALUE (not per category) -- see TAG_COLORS
  - a <dl> of 5 fields in a fixed order: Size as pinned, Technique,
    Fits per A4, Est. cost/unit, Selling potential
  - a header <select id="theme-select"> that must list every theme used,
    or that theme becomes unfilterable
  - a header <p> with a hardcoded "N ideas catalogued" count

If the gallery's HTML structure ever changes (new field, new filter,
restyled tags), this module needs updating BEFORE either skill is used
again -- don't assume old constants still apply after a manual edit to
the file. Re-run inspect_gallery() to check.
"""

import re
import base64
import mimetypes
from pathlib import Path


# ---------------------------------------------------------------------------
# Fixed colour-per-value mapping. Extracted from the real file, not
# invented -- every existing tag value in the gallery uses exactly one of
# these hex colours. If you introduce a NEW value the file hasn't seen
# before (a new Solutions code, a new Selling level), you must pick a
# colour and add it here -- don't guess a value into an existing card
# without also registering its colour, or the card will render with no
# background on that tag.
# ---------------------------------------------------------------------------

FITS_COLORS = {
    "True": "#2F5233",   # "Fits 100×140mm spec"
    "False": "#7A2E4D",  # "Future product (size/shape)"
}
FITS_LABELS = {"True": "Fits 100\u00d7140mm spec", "False": "Future product (size/shape)"}

CUTTING_COLORS = {
    "doable_now": "#2F5233",    # "Doable now"
    "needs_cricut": "#B0532E",  # "Needs Cricut"
}
CUTTING_LABELS = {"doable_now": "Doable now", "needs_cricut": "Needs Cricut"}

SELLING_COLORS = {
    "Very High": "#2F5233",
    "High": "#3D6B45",
    "Medium-High": "#8C7A2E",
    "Medium": "#B4841F",
    "N/A": "#9a988f",
}

SOLUTION_COLORS = {
    "WC": "#2F5233",
    "CV": "#1F3A5F",
    "PTC": "#B4841F",
    "CRICUT": "#B0532E",
    "NA": "#6b6a63",
}
SOLUTION_LABELS = {
    "WC": "White card", "CV": "Clear vinyl + colour", "PTC": "Print-Then-Cut",
    "CRICUT": "Cricut required", "NA": "Not applicable",
}


def inspect_gallery(path):
    """Prints current state: card count, highest ID, existing themes, and
    a spot-check that every tag colour this module knows about still
    matches what's actually in the file. Run this FIRST, before either
    skill touches the file -- if the spot-check reports mismatches, the
    file has been edited since this module was written and the constants
    above need updating before you trust anything else in this module."""
    html = Path(path).read_text()
    ids = re.findall(r'id-badge">(P\d+[a-z]?)', html)
    themes = sorted(set(re.findall(r'<option value="([^"]+)">[^<]+</option>', html.split('id="theme-select"')[1].split('</select>')[0])))
    card_count = html.count('class="card"')
    highest = max(int(re.match(r'P(\d+)', i).group(1)) for i in ids)
    print(f"cards: {card_count}, highest numeric id: P{highest:02d}")
    print(f"existing themes ({len(themes)}): {themes}")

    # spot-check colours actually found in the file against our table
    found_selling = dict(re.findall(r'selling-badge" style="background:(#[0-9A-Fa-f]{6})">Selling: ([^<]+)</span>', html))
    for label, hexval in [(v, k) for k, v in found_selling.items()]:
        pass
    mismatches = []
    for hexval, label in found_selling.items():
        label = label.strip()
        if SELLING_COLORS.get(label) != hexval:
            mismatches.append(("selling", label, hexval, SELLING_COLORS.get(label)))
    if mismatches:
        print("WARNING -- colour mismatches found, this module's constants may be stale:")
        for m in mismatches:
            print(" ", m)
    else:
        print("colour table check: OK (matches file)")
    return {"card_count": card_count, "themes": themes, "ids": ids}


def next_id(path):
    """Returns the next sequential P-number (e.g. 'P63'), based on the
    highest existing numeric ID. Ignores lettered variants (P09a etc.)."""
    html = Path(path).read_text()
    ids = re.findall(r'id-badge">P(\d+)', html)
    return f"P{max(int(i) for i in ids) + 1}"


def image_to_data_uri(image_path):
    """Converts a local image file to the inline base64 data URI format
    the gallery embeds directly in <img src="...">."""
    mime, _ = mimetypes.guess_type(image_path)
    mime = mime or "image/jpeg"
    data = Path(image_path).read_bytes()
    b64 = base64.b64encode(data).decode("ascii")
    return f"data:{mime};base64,{b64}"


def _esc(text):
    """HTML-escapes text the same way the existing file does (it uses
    numeric entities for apostrophes, not &apos;/&#39; mismatches --
    match that convention so a diff against hand-written cards is clean)."""
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("'", "&#x27;").replace('"', "&quot;"))


def render_card(entry):
    """Builds one complete <div class="card">...</div> block from an
    entry dict. Required keys: id, set, theme, title, image_desc,
    image_data_uri, fits ('True'/'False'), cutting
    ('doable_now'/'needs_cricut'), solutions (list of codes e.g.
    ['WC','CV']), selling (one of SELLING_COLORS' keys), size_pinned,
    technique, fits_per_a4, cost_unit, selling_note, notes.
    Optional: extra_dl_rows (list of (label, value) tuples appended
    after the 5 standard fields -- this is how gallery-mockup-prompt
    adds a "Mockup prompt" row without needing a different template)."""
    solutions_attr = " ".join(entry["solutions"])
    solution_spans = "".join(
        f'<span class="tag solution-tag" style="background:{SOLUTION_COLORS[s]}">{SOLUTION_LABELS[s]}</span>'
        for s in entry["solutions"]
    )
    extra_rows = ""
    for label, value in entry.get("extra_dl_rows", []):
        extra_rows += f"<dt>{_esc(label)}</dt><dd>{_esc(value)}</dd>"

    return f'''    <div class="card" data-set="{_esc(entry["set"])}" data-cutting="{entry["cutting"]}" data-fits="{entry["fits"]}" data-selling="{_esc(entry["selling"])}" data-solutions="{solutions_attr}">
      <img src="{entry["image_data_uri"]}">
      <div class="card-body">
        <div class="card-top">
          <span class="id-badge">{entry["id"]}</span>
          <span class="theme-badge">{_esc(entry["theme"])}</span>
        </div>
        <span class="set-badge">{_esc(entry["set"])}</span>
        <h3>{_esc(entry["title"])}</h3>
        <p class="image-desc">{_esc(entry["image_desc"])}</p>
        <div class="tags">
          <span class="tag" style="background:{FITS_COLORS[entry["fits"]]}">{FITS_LABELS[entry["fits"]]}</span>
          <span class="tag" style="background:{CUTTING_COLORS[entry["cutting"]]}">{CUTTING_LABELS[entry["cutting"]]}</span>
          <span class="tag selling-badge" style="background:{SELLING_COLORS[entry["selling"]]}">Selling: {_esc(entry["selling"])}</span>
        </div>
        <div class="tags solutions-row">{solution_spans}</div>
        <dl>
          <dt>Size as pinned</dt><dd>{_esc(entry["size_pinned"])}</dd>
          <dt>Technique</dt><dd>{_esc(entry["technique"])}</dd>
          <dt>Fits per A4</dt><dd>{_esc(entry["fits_per_a4"])}</dd>
          <dt>Est. cost/unit</dt><dd>{_esc(entry["cost_unit"])}</dd>
          <dt>Selling potential</dt><dd>{_esc(entry["selling_note"])}</dd>{extra_rows}
        </dl>
        <p class="notes">{entry["notes"]}</p>
      </div>
    </div>
'''


def insert_card(path, entry, out_path=None):
    """Inserts a new rendered card as the LAST card in the grid (before
    </div>\\n<script>), updates the theme dropdown if entry['theme'] is
    new, and updates the header count. Writes to out_path (or overwrites
    `path` if out_path is None). Returns the entry's assigned id for
    confirmation."""
    html = Path(path).read_text()
    card_html = render_card(entry)

    # insert before the closing </div> of the grid, right before <script>
    marker = '</div>\n<script>'
    assert marker in html, "grid-closing marker not found -- gallery structure may have changed, check inspect_gallery() output"
    html = html.replace(marker, card_html + marker, 1)

    # add theme to the dropdown if it's new
    if entry["theme"] not in re.findall(r'<option value="([^"]+)">', html.split('id="theme-select"')[1].split('</select>')[0]):
        theme_select_block = html.split('id="theme-select"')[1].split('</select>')[0]
        new_option = f'\n<option value="{_esc(entry["theme"])}">{_esc(entry["theme"])}</option>'
        # keep options alphabetically sorted, matching the existing convention
        options = re.findall(r'<option value="[^"]+">[^<]+</option>', theme_select_block)
        all_opts = options[1:] + [new_option.strip()]  # options[0] is "All Themes", keep first
        all_opts_sorted = sorted(all_opts, key=lambda o: re.search(r'>([^<]+)<', o).group(1))
        new_block = 'id="theme-select"><option value="all">All Themes</option>\n' + "\n".join(all_opts_sorted)
        html = html.replace('id="theme-select"' + theme_select_block, new_block, 1)

    # update the header count ("N ideas catalogued")
    def bump_count(m):
        return f"{int(m.group(1)) + 1} ideas catalogued"
    html = re.sub(r'(\d+) ideas catalogued', bump_count, html, count=1)

    out = out_path or path
    Path(out).write_text(html)
    return entry["id"]


def insert_dl_row(path, card_id, label, value, out_path=None):
    """Adds one new <dt>/<dd> row to an EXISTING card's <dl>, identified
    by its id-badge (e.g. 'P02'). Used by gallery-mockup-prompt to attach
    a mockup prompt to a design without touching anything else about it.
    Raises if the card isn't found, or if that label already exists on
    this card (re-run with a different label, or edit manually, rather
    than silently duplicating a field)."""
    html = Path(path).read_text()
    # find this card's block
    pattern = re.compile(
        r'(<div class="card"[^>]*>.*?<span class="id-badge">' + re.escape(card_id) +
        r'</span>.*?</dl>)', re.DOTALL
    )
    m = pattern.search(html)
    assert m, f"card {card_id} not found"
    card_block = m.group(1)
    if f"<dt>{_esc(label)}</dt>" in card_block:
        raise ValueError(f"{card_id} already has a '{label}' row -- edit manually if you meant to replace it")
    new_block = card_block[:-len("</dl>")] + f"<dt>{_esc(label)}</dt><dd>{_esc(value)}</dd></dl>"
    html = html[:m.start()] + new_block + html[m.end():]
    out = out_path or path
    Path(out).write_text(html)


def verify_gallery(path, expected_card_count=None):
    """Structural sanity check after writing: card count matches
    expectation, HTML is still parseable (balanced card divs), every
    card's id-badge is unique. Print-and-return, don't just trust the
    write succeeded."""
    html = Path(path).read_text()
    ids = re.findall(r'id-badge">([^<]+)</span>', html)
    dupes = [i for i in set(ids) if ids.count(i) > 1]
    open_cards = html.count('<div class="card"')
    close_ok = html.count('</div>\n<script>') == 1  # exactly one grid-close marker
    print(f"card count: {open_cards}, unique ids: {len(set(ids))}, duplicate ids: {dupes or 'none'}")
    print(f"grid-close marker present exactly once: {close_ok}")
    if expected_card_count is not None:
        ok = open_cards == expected_card_count and not dupes and close_ok
        print("VERIFY:", "OK" if ok else "MISMATCH -- do not ship this file, inspect before using")
        return ok
    return None
