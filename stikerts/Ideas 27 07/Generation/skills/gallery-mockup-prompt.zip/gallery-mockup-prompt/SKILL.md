---
name: gallery-mockup-prompt
description: Generates a full-layout mockup prompt (Midjourney and Lovart versions) for a design in bin_sticker_idea_gallery.html — a composition-reference-only image showing icon placement, spacing, and proportions with placeholder text, explicitly never used as final art or copied into bin_sticker.py. Adds the generated prompt(s) directly onto that design's card in the gallery HTML as new fields, not into any other file. Trigger this when the user asks for a "mockup prompt", "layout prompt", "full-layout" image prompt, or references wanting to see composition/proportions for a specific gallery entry (by P-number) before finalising placement. Do NOT use this for the icon-only art-generation prompt (a different, simpler prompt style meant to produce final reusable artwork) — this skill is specifically for the whole-layout composition reference, which deliberately includes placeholder text that gets thrown away.
---

# Gallery Mockup Prompt

Generates the "full-layout mockup" prompt pair (Midjourney + Lovart) for
a design already in `bin_sticker_idea_gallery.html`, and attaches it
directly to that entry's card as new fields — not to any separate guide
file. This is deliberately narrower than the icon-only art prompt: the
whole point of this prompt style is to explore **composition** (where the
number sits vs. the icon, how big a banner should be, spacing) with
placeholder text baked in that will never be used for real.

**Say this every time, not just once**: the resulting image's text is a
placeholder — blurry, possibly wrong, never traced, never copied into
`bin_sticker.py`. Only the layout/proportions are useful. This warning
belongs in the generated prompt output itself (both variants below
already include it), not just as advice you give verbally — repeating it
in the artifact is what makes it hard to miss later.

## Step 1: get the design's actual details

Read the target card from the gallery (by its P-number) — you need its
title, theme, and `image-desc` (what's actually in the source image) to
write a grounded prompt, not a generic one. If the design doesn't exist
in the gallery yet (a brand new concept being explored before intake),
work from whatever description the user gives directly instead.

## Step 2: fill in the two prompt templates

See `references/prompt-templates.md` for the exact wording pattern (this
is not invented — it's the real pattern already used for P02, generalised
with placeholders). Both variants:
- Use the *actual* icon elements and their arrangement from the design
  (don't genericise "a house with flowers" into "an icon" — specificity
  is what makes the mockup useful for judging real proportions)
- Use a real example number/street name as the placeholder text (reuse
  "36" / "GROVE STREET" unless the user has a preferred example, or the
  design isn't address-shaped at all — e.g. a numbers-only design just
  needs a placeholder number)
- Include the portrait `--ar 5:7` flag (Midjourney) or the equivalent
  "roughly 100mm wide by 140mm tall" phrasing (Lovart) — this matches the
  card's real 100×140mm proportions. Skip/adjust this if the design in
  question is explicitly NOT meant for the standard card size (check its
  `fits` field).
- End with the same "reference only, not final art" framing — don't
  paraphrase this away for brevity, it's the one thing this prompt style
  exists to prevent someone from doing wrong later.

## Step 3: attach to the gallery entry

```python
import gallery_io as gio

gio.insert_dl_row(gallery_path, card_id, "Mockup prompt (Midjourney)", midjourney_prompt, out_path=out_path)
gio.insert_dl_row(out_path, card_id, "Mockup prompt (Lovart)", lovart_prompt, out_path=out_path)
gio.verify_gallery(out_path, expected_card_count=<unchanged>)
```

Note `insert_dl_row` raises if that card already has a row with the same
label — if the user's regenerating a prompt for a design they've already
done this for, that's a deliberate signal to check with them (replace by
hand, or pick a different label like "Mockup prompt (Midjourney) v2")
rather than silently overwriting or silently failing.

## Step 4: give the user the prompts directly too

Don't make them open the HTML file to get the text they need to paste
into Midjourney/Lovart — output both prompts directly in your reply as
well as writing them into the gallery file.

## What NOT to do

- Don't touch `Midjourney-Beginner-Guide.md` or `Lovart-Beginner-Guide.md`
  — this skill's output goes in the gallery HTML only (that was a
  deliberate choice, different from how this was done the first time).
- Don't generate the icon-only art prompt here — that's a different
  prompt style (no placeholder text at all, meant to produce actual
  reusable artwork) and belongs to a different task.
- Don't silently drop the "reference only" warning to make the prompt
  shorter.
